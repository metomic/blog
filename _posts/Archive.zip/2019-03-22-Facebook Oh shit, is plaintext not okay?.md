---
layout: post
title:  "Facebook: Oh shit, is plaintext not okay?"
categories: ["Weekly Roundup"]
author: "Georgia Iacovou"
socialImage: /images/plaintext.png
themeColor: "#E89668"
date:   2019-03-22 12:56:00

---

## "One porn, please"

By next month in the UK, if you want to watch porn you'll have to prove you're over 18 by providing ID to your porn site of choice. Law makers kept this one quiet didn't they? Alternatively, you can purchase a porn pass from the newsagent, and they will verify your age in person like when you buy alcohol. Can you imagine? You pop to the newsagent to buy milk and then think 'oh yeah I better get a porn pass while I'm at it for all that porn I'm going to watch later'. Who is actually going to do that? No one - no one is going to do that. 

Polling shows that 67% of people think this is a good idea but only 34% of people asked about this actually think it's going to work. That's because it's not going to work. Have you ever heard of a VPN? People under the age of 18 certainly have. 

What's more, law-abiding adults who watch porn through the 'proper channels' will be handing their information over to porn sites which means there will be identifiable data out there about how much porn you watch and what kind. Which I'm sure will never ever be used against you...

## Facebook have been storing passwords in plaintext for seven years, GREAT.

Seriously though, will Facebook ever stop finding new ways to fuck up? Why would you store passwords in plaintext? Why would you do that? Why don't you just cut out the middle man and publish them all on your blog for everyone to see?

This has affected somewhere between 200 and 600 million users, and logging passwords in this way began in 2012. There are 20,000 Facebook employees that had access to these logs. Guys... at this point I'm embarrassed for you. This isn't large scale negligence, this is a result of disgraceful office culture, expertly cultivated over many years. "Yes, we store passwords in plaintext, but keep your head down, your mouth shut, and meet your deadlines."

![](/images/plaintext.png)

## Wow cool, Myspace. What a throwback

The age of cringing at your old Myspace profile is now over. No more nostalgia for you, sorry. Myspace just lost 12 years worth of songs and other data in a server migration project. I can't quite grasp how negligent you have to be in order to lose that much data. This also poses another problem: what will it be like for us in 50 years if all the tech giants we rely on to store our memories keep losing them? 

## Singapore starting data portability conversation.

Singapore are trying to push an amendment onto the PDPA (Privacy Data Protection Act). The amendment is all about data portability - in essence, the data you produce by using an app or service should be retrievable in a standardised format that can be transferred and read by another, similar service. This means if you've been using a fitness app for ages but really want to switch to another one, you can do this without losing all your stats. A great conversation and a step in the right direction.

## So, *I* need to take *you* to court to get what I'm legally entitled to?

If you're an Uber driver, you will generate heaps of data for Uber such as the routes you take, how many fares you complete, how much time you've logged, etc. According to GDPR, drivers should be allowed access to this data whenever they like. It is, after all, data that they produced. It's come to light, however, that Uber are somehow above the law. Four Uber drivers recently had to take Uber to court in order to get the data that they are legally entitled to.

Imagine going to the police with 'these guys are not GDPR compliant'. You'd be laughed out of the station. What if we had a system in place so that reporting this kind of thing felt the same as reporting theft?